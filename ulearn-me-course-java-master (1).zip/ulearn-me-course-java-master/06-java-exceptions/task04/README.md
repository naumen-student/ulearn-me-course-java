# Задание 04 Кидаем своё исключение

Модифицируем решение задания 02.
Сперва создайте в пакете `com.example.task04` свой класс исключения `MyException`
унаследованный от `IllegalArgumentException`. 
Скопируйте реализацию метода `static String getSeason(int monthNumber)` из решения задания 02
и вместо `IllegalArgumentException` кидайте `MyException`.
