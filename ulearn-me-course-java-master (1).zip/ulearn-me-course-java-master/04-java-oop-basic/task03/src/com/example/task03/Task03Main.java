package com.example.task03;

public class Task03Main {
    public static void main(String[] args) {

    }
}
