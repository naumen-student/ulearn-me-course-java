package com.example.task01;

public class Task01 {

    public static String solution() {

        // TODO напишите здесь свою корректную реализацию этого метода, вместо сеществующей

        return "здесь какая-то неправильная строка";
    }

    public static void main(String[] args) {
        // Здесь вы можете вручную протестировать ваше решение, вызывая реализуемый метод и смотря результат
        // например вот так:
        /*
        String result = solution();
        System.out.println(result);
         */
    }

}
