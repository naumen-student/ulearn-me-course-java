package com.example.task02;

public class Task02Main {
    public static void main(String[] args) {

    }
}
