# 10. Функциональные интерфейсы. Stream API

## Список задач:
* 01 - ternaryOperator 2/20
* 02 - Gray Code 4/20
* 03 - minMaxConsumer 2/20
* 04 - Топ10 5/20
* 05 - MailService 7/20
