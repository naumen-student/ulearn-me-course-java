package com.example.task01;

public class Task01Main {
    public static void main(String[] args) {
        //здесь вы можете вручную протестировать ваше решение, вызывая реализуемый метод и смотря результат
        // например вот так:
        /*
        boolean b = canGetDriverLicense(100);
        System.out.println(b);
         */
    }

    static boolean canGetDriverLicense(int age) {
        return true;//todo напишите здесь свою корректную реализацию этого метода, вместо существующей
    }
}
