# Задание 03 Кидаем checked исключение

Напишите метод `static void throwCheckedException()` который будет кидать `checked` исключение. 
