package com.example.task01;

public class Pair {
    // TODO напишите реализацию
}
