# Задание 01 - Hello, World!

Создайте класс HelloWorld и напишите в нём main метод, выводящий в консоль "Hello, World!"