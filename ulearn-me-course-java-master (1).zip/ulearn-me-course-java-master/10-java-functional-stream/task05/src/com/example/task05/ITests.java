package com.example.task05;

public interface ITests {

    void testExample();

}
