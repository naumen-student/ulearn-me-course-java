package com.example.task05;

public class Task05Main {
    public static void main(String[] args) {

    }
}
