package com.example.task07;

public class Processor {

    public Object process() throws Exception {
        //todo вы можете заменить реализацию этого метода для ручного дебага
        return null;
    }

}
