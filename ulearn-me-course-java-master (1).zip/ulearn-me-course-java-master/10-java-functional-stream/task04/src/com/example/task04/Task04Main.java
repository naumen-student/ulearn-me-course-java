package com.example.task04;

public class Task04Main {

    public static void main(String[] args) {

        // your implementation here

    }

}
