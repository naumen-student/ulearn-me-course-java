# Задание 01 Код с NPE

Напишите в методе `codeWithNPE` код в результате работы которого случится `NullPointerException`
```java
static void codeWithNPE()
```