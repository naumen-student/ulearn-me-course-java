package com.example.task04;

public class Task04Main {
    public static void main(String[] args) {
        //здесь вы можете вручную протестировать ваше решение, вызывая реализуемый метод и смотря результат
        // например вот так:
        /*
        from0to10000();
         */
    }

    static void from0to10000() {
        //todo напишите здесь свою корректную реализацию этого метода, вместо существующей
    }

}