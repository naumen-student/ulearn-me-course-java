package com.example.task03;

public class Minutes implements TimeUnit {

    public Minutes(long amount) {
        // TODO: реализовать
        throw new UnsupportedOperationException();
    }

    @Override
    public long toMillis() {
        // TODO: реализовать
        throw new UnsupportedOperationException();
    }

    @Override
    public long toSeconds() {
        // TODO: реализовать
        throw new UnsupportedOperationException();
    }

    @Override
    public long toMinutes() {
        // TODO: реализовать
        throw new UnsupportedOperationException();
    }
}
