package com.example.task01;

public interface ITests {
    void testNonEmpty();

    void testIfPresent();

    void testEmpty();

    void testHalfEmpty();

    void testEquals();
}
